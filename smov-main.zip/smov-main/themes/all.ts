import teal from "./list/teal";
import blue from "./list/blue";
import red from "./list/red";
import gray from "./list/gray";
import blck from "./list/blck";

export const allThemes = [
  teal,
  blue,
  gray,
  red,
  blck
]
